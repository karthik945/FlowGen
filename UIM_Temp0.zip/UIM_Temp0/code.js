"use strict";
// code.ts
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * This is our "Audit" engine. It now safely handles broken components.
 */
function catalogDesignSystem() {
    return __awaiter(this, void 0, void 0, function* () {
        yield figma.loadAllPagesAsync();
        const componentSchemas = {};
        const componentSets = figma.root.findAllWithCriteria({
            types: ['COMPONENT_SET']
        });
        for (const set of componentSets) {
            const schema = {
                id: set.id,
                name: set.name,
                properties: {}
            };
            // We wrap the part that might fail in a try...catch block.
            try {
                const properties = set.componentPropertyDefinitions;
                for (const propName in properties) {
                    const prop = properties[propName];
                    schema.properties[propName] = {
                        type: prop.type,
                        defaultValue: prop.defaultValue,
                        options: prop.type === 'VARIANT' ? prop.variantOptions : undefined
                    };
                }
                componentSchemas[set.name] = schema;
            }
            catch (e) { // --- THIS IS THE FIX ---
                // If Figma throws an error, we catch it and check its type before using it.
                if (e instanceof Error) {
                    console.error(`Skipping component set "${set.name}" due to error:`, e.message);
                }
                else {
                    console.error(`Skipping component set "${set.name}" due to an unknown error.`);
                }
            }
        }
        // You can also add logic here to find simple components that are NOT in a set.
        // ...
        return componentSchemas;
    });
}
/**
 * This is the main function that kicks everything off.
 */
function startPlugin() {
    return __awaiter(this, void 0, void 0, function* () {
        figma.showUI(__html__, { width: 360, height: 400 });
        const designSystemCatalog = yield catalogDesignSystem();
        figma.ui.postMessage({
            type: 'design-system-ready',
            catalog: designSystemCatalog,
        });
        figma.ui.onmessage = (msg) => __awaiter(this, void 0, void 0, function* () {
            if (msg.type === 'assemble-ui') {
                const allComponentSets = figma.root.findAllWithCriteria({ types: ['COMPONENT_SET'] });
                const nodesToCreate = [];
                let currentY = 0;
                for (const element of msg.data.elements) {
                    const componentSet = allComponentSets.find(cs => cs.name === element.componentName);
                    if (!componentSet) {
                        console.error(`Component Set named "${element.componentName}" not found.`);
                        continue;
                    }
                    const instance = componentSet.defaultVariant.createInstance();
                    instance.y = currentY;
                    try {
                        instance.setProperties(element.properties);
                    }
                    catch (e) {
                        console.error(`Failed to set properties for ${element.componentName}:`, e);
                    }
                    if (element.textOverrides) {
                        for (const override of element.textOverrides) {
                            const textLayer = instance.findOne(n => n.name === override.layerName && n.type === "TEXT");
                            if (textLayer) {
                                yield figma.loadFontAsync(textLayer.fontName);
                                textLayer.characters = override.text;
                            }
                            else {
                                console.warn(`Text layer "${override.layerName}" not found in component "${element.componentName}".`);
                            }
                        }
                    }
                    nodesToCreate.push(instance);
                    currentY += instance.height + 20;
                }
                figma.currentPage.selection = nodesToCreate;
                figma.viewport.scrollAndZoomIntoView(nodesToCreate);
                figma.closePlugin("UI Assembled Successfully!");
            }
        });
    });
}
// Start the plugin!
startPlugin();
