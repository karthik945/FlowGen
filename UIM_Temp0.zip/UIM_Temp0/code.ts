// code.ts

// --- Define the "blueprint" for our data ---
interface ComponentPropertySchema {
  type: ComponentPropertyType;
  defaultValue: any;
  options?: string[];
}

interface ComponentCatalog {
  [componentName: string]: {
    id: string;
    name: string;
    properties: { [propertyName: string]: ComponentPropertySchema };
  };
}


/**
 * This is our "Audit" engine. It now safely handles broken components.
 */
async function catalogDesignSystem(): Promise<ComponentCatalog> {
  await figma.loadAllPagesAsync();

  const componentSchemas: ComponentCatalog = {};

  const componentSets = figma.root.findAllWithCriteria({
    types: ['COMPONENT_SET']
  });

  for (const set of componentSets) {
    const schema = {
      id: set.id,
      name: set.name,
      properties: {} as { [propertyName: string]: ComponentPropertySchema }
    };

    // We wrap the part that might fail in a try...catch block.
    try {
      const properties = set.componentPropertyDefinitions;
      for (const propName in properties) {
        const prop = properties[propName];
        schema.properties[propName] = {
          type: prop.type,
          defaultValue: prop.defaultValue,
          options: prop.type === 'VARIANT' ? prop.variantOptions : undefined
        };
      }
      componentSchemas[set.name] = schema;
    } catch (e: unknown) { // --- THIS IS THE FIX ---
      // If Figma throws an error, we catch it and check its type before using it.
      if (e instanceof Error) {
        console.error(`Skipping component set "${set.name}" due to error:`, e.message);
      } else {
        console.error(`Skipping component set "${set.name}" due to an unknown error.`);
      }
    }
  }

  // You can also add logic here to find simple components that are NOT in a set.
  // ...

  return componentSchemas;
}


/**
 * This is the main function that kicks everything off.
 */
async function startPlugin() {
  figma.showUI(__html__, { width: 360, height: 400 });

  const designSystemCatalog = await catalogDesignSystem();

  figma.ui.postMessage({
    type: 'design-system-ready',
    catalog: designSystemCatalog,
  });

  figma.ui.onmessage = async (msg) => {
    if (msg.type === 'assemble-ui') {
      const allComponentSets = figma.root.findAllWithCriteria({ types: ['COMPONENT_SET'] }) as ComponentSetNode[];
      const nodesToCreate: SceneNode[] = [];
      let currentY = 0;

      for (const element of msg.data.elements) {
        const componentSet = allComponentSets.find(cs => cs.name === element.componentName);

        if (!componentSet) {
          console.error(`Component Set named "${element.componentName}" not found.`);
          continue;
        }

        const instance = componentSet.defaultVariant.createInstance();
        instance.y = currentY;
        
        try {
          instance.setProperties(element.properties);
        } catch (e) {
          console.error(`Failed to set properties for ${element.componentName}:`, e);
        }

        if (element.textOverrides) {
          for (const override of element.textOverrides) {
            const textLayer = instance.findOne(n => n.name === override.layerName && n.type === "TEXT") as TextNode;
            if (textLayer) {
              await figma.loadFontAsync(textLayer.fontName as FontName);
              textLayer.characters = override.text;
            } else {
              console.warn(`Text layer "${override.layerName}" not found in component "${element.componentName}".`);
            }
          }
        }
        
        nodesToCreate.push(instance);
        currentY += instance.height + 20;
      }

      figma.currentPage.selection = nodesToCreate;
      figma.viewport.scrollAndZoomIntoView(nodesToCreate);
      figma.closePlugin("UI Assembled Successfully!");
    }
  };
}

// Start the plugin!
startPlugin();